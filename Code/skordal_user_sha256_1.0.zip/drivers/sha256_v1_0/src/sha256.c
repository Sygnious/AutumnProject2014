// SHA256 Hashing Module - Software Driver
// Kristian Klomsten Skordal <kristian.skordal@wafflemail.net>

#include <xil_io.h>
#include "sha256.h"

void sha256_reset(u32 base)
{
	SHA256_WRITE_REG(base, SHA256_CONTROL_REG_OFFSET,
		1 << SHA256_CONTROL_RESET | 1 << SHA256_CONTROL_ENABLE);
	SHA256_WRITE_REG(base, SHA256_CONTROL_REG_OFFSET,
		1 << SHA256_CONTROL_ENABLE);
}

void sha256_hash(u32 base)
{
	SHA256_WRITE_REG(base, SHA256_CONTROL_REG_OFFSET, 1 << SHA256_CONTROL_ENABLE | 1 << SHA256_CONTROL_UPDATE);
	SHA256_WRITE_REG(base, SHA256_CONTROL_REG_OFFSET, 1 << SHA256_CONTROL_ENABLE);
	while(!(SHA256_READ_REG(base, SHA256_STATUS_REG_OFFSET) & (1 << SHA256_STATUS_READY)));
}

void sha256_get_hash(u32 base, u8 * hash)
{
	int i; // This gets around the SDK's stupid default C89 mode...
	for(i = 0; i < 8; ++i)
	{
		u32 value = SHA256_READ_REG(base, SHA256_HASH_REG_OFFSET(i));
		hash[i * 4 + 3] = value & 0xff;
		hash[i * 4 + 2] = (value >> 8) & 0xff;
		hash[i * 4 + 1] = (value >> 16) & 0xff;
		hash[i * 4 + 0] = (value >> 24) & 0xff;
	}
}
